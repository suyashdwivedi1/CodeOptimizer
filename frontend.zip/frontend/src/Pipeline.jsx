import React from "react";
import { CheckCircle2, Circle, Loader2, XCircle, MinusCircle } from "lucide-react";

const ICON = {
  pending: <Circle size={14} className="st-pending" />, running: <Loader2 size={14} className="st-running spin" />,
  completed: <CheckCircle2 size={14} className="st-ok" />, failed: <XCircle size={14} className="st-fail" />,
  skipped: <MinusCircle size={14} className="st-skip" />,
};

export default function Pipeline({ stages, state, connection }) {
  return (
    <div className="panel">
      <div className="panel-h"><span>Live pipeline</span>
        {connection && <span className={`pill ${connection === "live" ? "ok" : connection === "reconnecting" ? "warn" : ""}`}>{connection}</span>}
      </div>
      <ul className="stages">
        {stages.map((s, i) => {
          const st = state[s.id] || { status: "pending" };
          return (
            <li key={s.id} className={`stage ${st.status}`}>
              <span className="ic">{ICON[st.status] || ICON.pending}</span>
              <span className="num">{i + 1}</span>
              <div className="body">
                <div className="name">{s.label}</div>
                {st.message && st.status !== "pending" && <div className="msg">{st.message}</div>}
                {st.logs?.map((l, j) => <div key={j} className="msg log">· {l}</div>)}
              </div>
              <div className="time">{st.elapsed_ms != null ? `${(st.elapsed_ms / 1000).toFixed(2)}s` : st.ts ? new Date(st.ts).toLocaleTimeString() : ""}</div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
