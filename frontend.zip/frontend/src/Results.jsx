import React, { useEffect, useState } from "react";
import { Copy, Download, Trophy, AlertTriangle, Brain, Play } from "lucide-react";
import { api, downloadUrl } from "./api.js";
import CodeEditor from "./CodeEditor.jsx";
import Charts from "./Charts.jsx";
import { fmtBytes, fmtMs, fmtPct, fmtX } from "./util.js";

export function Banner({ r }) {
  if (!r) return null;
  const cls = r.status !== "completed" ? "bad" : ["clear"].includes(r.winner_status) ? "ok" : "warn";
  const text = r.status !== "completed" ? (r.error_summary || r.status) : r.report?.headline || r.error_summary || "Completed";
  return <div className={`banner ${cls}`}>{cls === "bad" ? <AlertTriangle size={16} /> : <Trophy size={16} />}<div><b>{r.status === "completed" ? "Result" : r.status.toUpperCase()}:</b> {text}
    {r.winner_status === "practical_tie" && <div className="sub">Differences are within measurement noise, so no single winner is highlighted.</div>}
    {r.winner_status === "below_threshold" && <div className="sub">The program runs too fast to measure reliably.</div>}</div></div>;
}

function Badge({ v }) {
  if (v.is_winner) return <span className="pill win">winner</span>;
  if (v.duplicate_of) return <span className="pill">≡ {v.duplicate_of}</span>;
  if (v.correctness_status === "failed") return <span className="pill bad">incorrect</span>;
  if (v.compile_status === "failed") return <span className="pill bad">compile failed</span>;
  if (v.compile_status === "skipped") return <span className="pill">skipped</span>;
  return null;
}

export function VariantTable({ variants, selected, onSelect }) {
  return (
    <div className="tablewrap"><table className="tbl">
      <thead><tr><th>Variant</th><th>Strategy</th><th>Compile</th><th>Correct</th><th className="r">Median</th><th className="r">Speedup</th><th className="r">Δ time</th><th className="r">Size</th><th className="r">Runs</th><th></th></tr></thead>
      <tbody>{variants.map((v) => (
        <tr key={v.id} className={`${selected === v.id ? "sel" : ""} ${v.is_winner ? "winrow" : ""}`} onClick={() => onSelect(v.id)}>
          <td><b>{v.strategy_id}</b>{v.ml_selected && <span className="pill ml" title="Top pick of the trained ML model">ML pick</span>}{v.is_baseline && <span className="pill">baseline</span>}</td>
          <td className="dim">{v.kind.replace("_", " ")}</td><td>{v.compile_status}</td><td>{v.correctness_status}</td>
          <td className="r">{fmtMs(v.median_ms)}</td><td className="r">{fmtX(v.speedup)}</td><td className="r">{fmtPct(v.time_reduction_pct)}</td>
          <td className="r">{fmtBytes(v.binary_size)}</td><td className="r">{v.benchmark_count || "—"}</td><td><Badge v={v} /></td>
        </tr>))}</tbody>
    </table></div>
  );
}

export function VariantDetail({ exp, v }) {
  const [tab, setTab] = useState("source");
  const [src, setSrc] = useState(null);
  const [ir, setIr] = useState(null);
  useEffect(() => { setSrc(null); setIr(null); setTab(v.has_source ? "source" : "ir"); }, [v.id]);
  useEffect(() => {
    if (tab === "source" && src == null) api.source(exp.id, v.id).then(setSrc).catch((e) => setSrc({ error: e.message }));
    if (tab === "ir" && ir == null) api.ir(exp.id, v.id).then(setIr).catch((e) => setIr({ error: e.message }));
  }, [tab, v.id]);
  const text = tab === "source" ? src?.source : ir?.ir;
  const copy = () => text && navigator.clipboard?.writeText(text);
  return (
    <div className="panel">
      <div className="panel-h"><span>{v.strategy_id} — {v.name}</span>
        <div className="tabs">{["source", "ir", "passes", "benchmark"].map((t) => <button key={t} className={tab === t ? "on" : ""} onClick={() => setTab(t)}>{{ source: "Source", ir: "LLVM IR", passes: "Passes & flags", benchmark: "Benchmark" }[t]}</button>)}</div></div>
      <div className="detail">
        {tab === "source" && (src?.error ? <div className="note">{src.error}</div> : src ? <>
          <div className="toolbar"><span className="dim">{src.kind === "transformed" ? "Transformed source (real source-level change)" : "Original input (unchanged)"}</span>
            <button className="btn sm" onClick={copy}><Copy size={13} />Copy</button>
            <a className="btn sm" href={downloadUrl(exp.id, v.id, "source")}><Download size={13} />Download</a></div>
          <div className="code"><CodeEditor value={src.source} readOnly language={exp.language} /></div></> : <div className="empty">Loading…</div>)}
        {tab === "ir" && (ir?.error ? <div className="note">{ir.error}</div> : ir ? <>
          <div className="toolbar"><span className="dim">Post-optimisation LLVM IR for this configuration</span>
            <button className="btn sm" onClick={copy}><Copy size={13} />Copy</button>
            <a className="btn sm" href={downloadUrl(exp.id, v.id, "ir")}><Download size={13} />Download .ll</a></div>
          <div className="code"><CodeEditor value={ir.ir} readOnly language="ll" /></div></> : <div className="empty">Generating IR…</div>)}
        {tab === "passes" && <div className="pad">
          <p className="dim">{v.description}</p>
          <div className="kv"><span>Flags</span><code>{(v.flags || []).join(" ") || "—"}</code></div>
          {v.pipeline && <div className="kv"><span>Pass pipeline</span><code className="wrap">{v.pipeline.slice(0, 600)}{v.pipeline.length > 600 ? "…" : ""}</code></div>}
          <div className="kv"><span>Techniques with a pass present</span><span>{(v.techniques || []).map((t) => <span key={t} className="pill">{t}</span>)}{!v.techniques?.length && "none"}</span></div>
          <div className="kv"><span>Compile time</span><span>{fmtMs(v.compile_time_ms)}</span></div>
          {v.applied_passes?.length > 0 && <details><summary>{v.applied_passes.length} top-level passes</summary><div className="passlist">{v.applied_passes.map((p, i) => <code key={i}>{p.slice(0, 90)}</code>)}</div></details>}
          {v.remarks?.length > 0 && <><h4>Vectorisation remarks (LLVM)</h4>{v.remarks.slice(0, 12).map((r, i) => <div key={i} className={`remark ${r.status}`}>line {r.line}: {r.message}</div>)}</>}
          {v.warnings?.map((w, i) => <div key={i} className="note">{w}</div>)}
        </div>}
        {tab === "benchmark" && <div className="pad">
          <div className="grid4">
            {[["Median", fmtMs(v.median_ms)], ["Mean", fmtMs(v.mean_ms)], ["Std-dev", fmtMs(v.stdev_ms)], ["IQR", fmtMs(v.iqr_ms)], ["Min", fmtMs(v.min_ms)], ["Max", fmtMs(v.max_ms)], ["Samples", v.benchmark_count], ["Peak RSS", v.peak_rss_kb ? `${(v.peak_rss_kb / 1024).toFixed(1)} MB` : "—"]].map(([k, x]) => <div key={k} className="stat"><div className="k">{k}</div><div className="v">{x}</div></div>)}
          </div>
          {v.failure_reason && <div className="note bad">{v.failure_reason}</div>}
          {v.duplicate_of && <div className="note">Machine code is byte-identical to {v.duplicate_of}; it is not benchmarked separately.</div>}
          {v.samples_ms && <div className="dim small">Raw samples (ms): {v.samples_ms.map((x) => x.toFixed(2)).join(", ")}</div>}
        </div>}
      </div>
    </div>
  );
}

export function MLDecision({ exp }) {
  const p = exp.ml_prediction;
  if (!p) return null;
  return (
    <div className="panel">
      <div className="panel-h"><span><Brain size={14} /> ML decision</span><span className={`pill ${p.is_ml ? "ml" : "warn"}`}>{p.is_ml ? `trained model ${p.model_version}` : "NOT ML — fallback order"}</span></div>
      <div className="pad">
        <p className="dim">{p.note}</p>
        <div className="kv"><span>Top pick</span><b>{p.top_pick}</b></div>
        <div className="kv"><span>Inference time</span><span>{p.inference_ms?.toFixed(1)} ms</span></div>
        <table className="tbl small"><thead><tr><th>Rank</th><th>Strategy</th><th className="r">{p.is_ml ? "Predicted time vs O2" : "—"}</th><th className="r">Spread</th><th className="r">Measured</th></tr></thead>
          <tbody>{p.ranking.slice(0, 8).map((r) => {
            const v = exp.variants.find((x) => x.strategy_id === r.strategy_id);
            return <tr key={r.strategy_id}><td>{r.rank}</td><td>{r.strategy_id}</td><td className="r">{r.predicted_rel_time != null ? `${r.predicted_rel_time.toFixed(3)}×` : "—"}</td><td className="r">{r.spread != null ? r.spread.toFixed(3) : "—"}</td><td className="r">{v?.median_ms != null ? fmtMs(v.median_ms) : v?.duplicate_of ? `identical binary to ${v.duplicate_of}` : v ? "not measured" : "not evaluated"}</td></tr>;
          })}</tbody></table>
        {exp.report?.ml_pick && <div className="note">ML pick measured at {fmtMs(exp.report.ml_pick.median_ms)} — {exp.report.ml_pick.regret_vs_best_pct.toFixed(1)}% slower than the best measured variant{exp.report.ml_pick.vs_o2_speedup != null ? `; ${exp.report.ml_pick.vs_o2_speedup.toFixed(2)}× vs O2` : ""}.</div>}
        {p.explanation && <><h4>Features the model relies on</h4><div className="dim small">{p.explanation.method}. {p.explanation.caveat}</div>
          {p.explanation.top_features.map((f) => <div key={f.feature} className="fbar"><span>{f.feature}</span><div><i style={{ width: `${Math.min(100, f.importance * 300)}%` }} /></div><em>{f.value.toFixed(f.value % 1 ? 2 : 0)} ({f.relative} median)</em></div>)}</>}
      </div>
    </div>
  );
}

export function Complexity({ exp }) {
  const c = exp.complexity; const b = exp.variants.find((v) => v.is_baseline); const best = exp.variants.find((v) => v.id === exp.best_variant_id);
  if (!c) return null;
  return (
    <div className="panel"><div className="panel-h"><span>Complexity analysis</span></div>
      <div className="split pad">
        <div><h4>Algorithmic (heuristic estimate)</h4>
          <div className="kv"><span>Time</span><b>{c.time.estimate}</b></div><div className="kv"><span>Space</span><b>{c.space.estimate}</b></div>
          <div className="dim small">{c.method}</div>{c.time.reasons.map((r, i) => <div key={i} className="dim small">· {r}</div>)}</div>
        <div><h4>Empirical (measured)</h4>
          <div className="kv"><span>Baseline</span><b>{fmtMs(b?.median_ms)}</b></div><div className="kv"><span>Fastest variant</span><b>{best ? `${best.strategy_id}: ${fmtMs(best.median_ms)}` : "—"}</b></div>
          <div className="kv"><span>Speedup</span><b>{fmtX(best?.speedup)}</b></div>
          <div className="dim small">{c.note}</div></div>
      </div></div>
  );
}

export function WhatIf({ exp, onChange }) {
  const [data, setData] = useState(null); const [busy, setBusy] = useState(null); const [err, setErr] = useState("");
  useEffect(() => { api.whatif(exp.id).then(setData).catch(() => {}); }, [exp.id, exp.variants.length]);
  if (!data) return null;
  const run = async (id) => { setBusy(id); setErr(""); try { await api.whatifRun(exp.id, [id]); await onChange(); } catch (e) { setErr(e.message); } setBusy(null); };
  return (
    <div className="panel"><div className="panel-h"><span>What-if: compare configurations</span></div>
      <div className="pad"><div className="dim small">Measured values come from this experiment. Unmeasured configurations show no numbers until you run them.</div>
        {err && <div className="note bad">{err}</div>}
        <table className="tbl small"><thead><tr><th>Configuration</th><th>Flags / pipeline</th><th className="r">Median</th><th className="r">Speedup</th><th></th></tr></thead>
          <tbody>{data.strategies.map((s) => <tr key={s.id}><td><b>{s.id}</b></td><td className="dim">{s.flags.join(" ") || s.pipeline?.slice(0, 50)}</td>
            <td className="r">{s.measured ? fmtMs(s.median_ms) : s.duplicate_of ? `≡ ${s.duplicate_of}` : <span className="dim">unmeasured</span>}</td><td className="r">{s.measured ? fmtX(s.speedup) : "—"}</td>
            <td className="r">{!s.measured && !s.duplicate_of && s.available && s.status !== "skipped" && <button className="btn sm" disabled={busy != null} onClick={() => run(s.id)}><Play size={12} />{busy === s.id ? "Measuring…" : "Measure"}</button>}{!s.available && <span className="dim">{s.unavailable_reason}</span>}</td></tr>)}</tbody></table></div></div>
  );
}

export default function Results({ exp, reload }) {
  const [sel, setSel] = useState(null);
  useEffect(() => { setSel(exp.best_variant_id || exp.variants[0]?.id); }, [exp.id]);
  const v = exp.variants.find((x) => x.id === sel);
  const failed = exp.status !== "completed";
  return (
    <div className="results">
      <Banner r={exp} />
      {!failed && exp.report?.notes?.map((n, i) => <div key={i} className="note">{n}</div>)}
      {!failed && exp.report?.skipped_strategies && Object.keys(exp.report.skipped_strategies).length > 0 && <div className="note">Unavailable strategies: {Object.entries(exp.report.skipped_strategies).map(([k, w]) => `${k} (${w})`).join("; ")}</div>}
      {exp.variants.length > 0 && <>
        <div className="panel"><div className="panel-h"><span>Variants — baseline + {exp.variants.filter((x) => !x.is_baseline).length} candidates</span><span className="dim small">click a row to inspect</span></div>
          <VariantTable variants={exp.variants} selected={sel} onSelect={setSel} /></div>
        {v && <VariantDetail exp={exp} v={v} />}
        <div className="panel"><div className="panel-h"><span>Performance charts</span><span className="legend"><i className="c-win" />winner <i className="c-opt" />variant <i className="c-ml" />ML pick <i className="c-base" />baseline</span></div><Charts variants={exp.variants} /></div>
        <MLDecision exp={exp} /><Complexity exp={exp} />
        {exp.status === "completed" && <WhatIf exp={exp} onChange={reload} />}
        {exp.report && <div className="panel"><div className="panel-h"><span>Measurement method</span></div><div className="pad dim small">
          {exp.report.environment && <>Mode <b>{exp.report.environment.mode}</b>, {exp.report.environment.repetitions} repetitions + {exp.report.environment.warmup} warm-up, {exp.report.environment.timer}. Platform {exp.report.environment.platform}; {exp.report.environment.clang}.<br /></>}
          Practical-tie tolerance {exp.report.noise_tie_pct}% (or IQR/2); reliability threshold {exp.report.reliable_min_ms} ms. {exp.report.empirical_note}</div></div>}
      </>}
    </div>
  );
}
