import React, { useCallback, useEffect, useRef, useState } from "react";
import { Activity, BarChart3, Brain, Cpu, FileCode2, History, LayoutDashboard, Settings as Cog, Upload, Play, Search, RotateCcw, Trash2, XCircle, StopCircle } from "lucide-react";
import { api } from "./api.js";
import CodeEditor from "./CodeEditor.jsx";
import Pipeline from "./Pipeline.jsx";
import Results, { Banner, MLDecision, Complexity, VariantTable, WhatIf } from "./Results.jsx";
import Charts, { ChartBox, COLORS, TOOLTIP } from "./Charts.jsx";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { fmtMs, fmtTime, fmtX } from "./util.js";

const DEFAULT_SRC = `#include <stdio.h>\n\nint main(void) {\n    long s = 0;\n    for (int i = 0; i < 1000; i++) s += i;\n    printf("%ld\\n", s);\n    return 0;\n}\n`;
const NAV = [["overview", "Overview", LayoutDashboard], ["optimizer", "Code Optimizer", FileCode2], ["analysis", "Analysis", Search], ["benchmarks", "Benchmarks", BarChart3], ["history", "Experiment History", History], ["ml", "ML Model", Brain], ["settings", "Settings", Cog]];

export default function App() {
  const [page, setPage] = useState("optimizer");
  const [health, setHealth] = useState(null);
  const [ml, setMl] = useState(null);
  const [stages, setStages] = useState([]);
  const [src, setSrc] = useState(DEFAULT_SRC);
  const [lang, setLang] = useState("c");
  const [filename, setFilename] = useState(null);
  const [stdin, setStdin] = useState("");
  const [mode, setMode] = useState("quick");
  const [useMl, setUseMl] = useState(true);
  const [dirty, setDirty] = useState(false);
  const [samples, setSamples] = useState([]);
  const [analysis, setAnalysis] = useState(null);
  const [exp, setExp] = useState(null);
  const [expId, setExpId] = useState(null);
  const [pstate, setPstate] = useState({});
  const [conn, setConn] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const esRef = useRef(null);

  const refreshStatus = useCallback(() => { api.health().then(setHealth).catch(() => setHealth(null)); api.mlStatus().then(setMl).catch(() => {}); }, []);
  useEffect(() => { refreshStatus(); api.stages().then(setStages).catch(() => {}); api.samples().then(setSamples).catch(() => {}); const t = setInterval(refreshStatus, 15000); return () => clearInterval(t); }, []);
  useEffect(() => { const h = (e) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } }; window.addEventListener("beforeunload", h); return () => window.removeEventListener("beforeunload", h); }, [dirty]);

  const confirmDiscard = () => !dirty || window.confirm("You have unsaved edits in the editor. Replace them?");
  const setSource = (s, l, f) => { setSrc(s); if (l) setLang(l); setFilename(f ?? null); setDirty(false); setAnalysis(null); };

  const loadSample = async (name) => { if (!name || !confirmDiscard()) return; try { const s = await api.sample(name); setSource(s.source, s.language, s.name); setStdin(s.stdin || ""); } catch (e) { setError(e.message); } };
  const upload = async (file) => { if (!file || !confirmDiscard()) return; setError(""); try { const r = await api.upload(file); setSource(r.source, r.language, r.filename); } catch (e) { setError(`Upload rejected: ${e.message}`); } };
  const clear = () => { if (confirmDiscard()) { setSource("", null, null); } };
  const reset = () => { if (!confirmDiscard()) return; closeEs(); setSource(DEFAULT_SRC, "c", null); setStdin(""); setExp(null); setExpId(null); setPstate({}); setConn(""); setError(""); };

  const runAnalysis = async () => {
    setError(""); setBusy(true);
    try { const a = await api.analyze({ source: src, language: lang, filename }); setAnalysis(a); if (a.compilation_status === "error") setError("Compilation failed — see diagnostics in the editor and the Analysis tab."); }
    catch (e) { setError(e.message); } setBusy(false);
  };

  const closeEs = () => { esRef.current?.close(); esRef.current = null; };
  const loadResults = async (id) => { const r = await api.results(id); setExp(r); setAnalysis(r.analysis || null); return r; };

  const subscribe = (id) => {
    closeEs(); setConn("connecting");
    const es = new EventSource(`/api/experiments/${id}/events`); esRef.current = es;
    es.onopen = () => setConn("live");
    es.onerror = () => setConn(es.readyState === EventSource.CLOSED ? "disconnected" : "reconnecting");
    es.addEventListener("progress", (m) => {
      const ev = JSON.parse(m.data);
      if (ev.stage === "experiment") { es.close(); setConn("finished"); setBusy(false); loadResults(id).then(refreshStatus); return; }
      setPstate((p) => {
        const cur = p[ev.stage] || { logs: [] };
        if (ev.status === "info") return { ...p, [ev.stage]: { ...cur, logs: [...(cur.logs || []), ev.message] } };
        return { ...p, [ev.stage]: { ...cur, status: ev.status, message: ev.message, elapsed_ms: ev.elapsed_ms, ts: ev.ts } };
      });
    });
  };

  const optimize = async () => {
    setError(""); setExp(null); setPstate({}); setBusy(true);
    try {
      const r = await api.optimize({ source: src, language: lang, filename, stdin, mode, use_ml: useMl, label: filename || "editor" });
      setExpId(r.experiment_id); subscribe(r.experiment_id);
    } catch (e) { setError(e.message); setBusy(false); }
  };
  const cancel = async () => { try { await api.cancel(expId); } catch (e) { setError(e.message); } };
  const openExperiment = async (id) => {
    setExpId(id); setPstate({}); const r = await loadResults(id); setSrc(r.source); setLang(r.language); setStdin(r.stdin || ""); setFilename(r.filename); setDirty(false);
    const ev = {}; try { const text = await fetch(`/api/experiments/${id}/events`).then((x) => x.text()); text.split("\n\n").forEach((blk) => { const l = blk.split("\n").find((z) => z.startsWith("data: ")); if (l) { const e = JSON.parse(l.slice(6)); if (e.stage !== "experiment" && e.status !== "info") ev[e.stage] = { status: e.status, message: e.message, elapsed_ms: e.elapsed_ms, ts: e.ts, logs: [] }; } }); } catch {}
    setPstate(ev); setConn(""); setPage("optimizer");
  };

  const diag = analysis?.diagnostics || [];
  const mlLabel = ml ? (ml.available ? `ML ${ml.version}` : "ML: not trained (baseline mode)") : "ML: unknown";
  const compilerOk = health?.compiler?.available;

  return (
    <div className="app">
      <aside className="side">
        <div className="brand"><Cpu size={18} /><div><b>Adaptive Compiler</b><small>Optimization Workbench</small></div></div>
        <nav>{NAV.map(([id, label, Icon]) => <button key={id} className={page === id ? "on" : ""} onClick={() => setPage(id)}><Icon size={16} />{label}</button>)}</nav>
        <div className="side-f">Clang/LLVM · scikit-learn<br />All processing is local.</div>
      </aside>
      <div className="main">
        <header className="top">
          <div className="title">AI-Driven Adaptive Compiler Optimization</div>
          <div className="chips">
            <span className={`chip ${compilerOk ? "ok" : "bad"}`}><Cpu size={12} />{compilerOk ? health.compiler.version?.replace(/\(.*\)/, "").trim() : "compiler missing"}</span>
            <span className={`chip ${ml?.available ? "ml" : "warn"}`}><Brain size={12} />{mlLabel}</span>
            <span className="chip"><Activity size={12} />{expId || "no experiment"}</span>
          </div>
        </header>
        <main className="content">
          {error && <div className="banner bad"><XCircle size={16} /><div>{error}</div><button className="x" onClick={() => setError("")}>×</button></div>}
          {page === "overview" && <Overview health={health} ml={ml} go={setPage} open={openExperiment} />}
          {page === "optimizer" && (
            <>
              <div className="warn-strip">Programs are compiled and executed natively on this machine. Timeouts and temp directories are not a security sandbox — only run code you trust.</div>
              <div className="opt-top">
                <div className="panel editor-panel">
                  <div className="panel-h"><span>Source input{filename ? ` — ${filename}` : ""}{dirty && <span className="pill warn">edited</span>}</span>
                    <div className="row">
                      <select value={lang} onChange={(e) => setLang(e.target.value)}><option value="c">C</option><option value="cpp">C++</option></select>
                      <select value="" onChange={(e) => loadSample(e.target.value)}><option value="">Sample program…</option>{samples.map((s) => <option key={s.name} value={s.name}>{s.title}</option>)}</select>
                      <label className="btn sm"><Upload size={13} />Upload<input type="file" hidden accept=".c,.cpp,.cc,.cxx" onChange={(e) => { upload(e.target.files[0]); e.target.value = ""; }} /></label>
                      <button className="btn sm" onClick={clear}>Clear</button>
                    </div></div>
                  <div className="drop" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); upload(e.dataTransfer.files[0]); }}>
                    <CodeEditor value={src} language={lang} markers={diag} onChange={(v) => { setSrc(v); setDirty(true); }} />
                  </div>
                  <div className="panel-f">
                    <textarea className="stdin" placeholder="stdin for the program (optional; identical for every variant)" value={stdin} onChange={(e) => setStdin(e.target.value)} rows={1} />
                    <select value={mode} onChange={(e) => setMode(e.target.value)} title="Benchmark mode"><option value="quick">Quick (few reps)</option><option value="rigorous">Rigorous (many reps)</option></select>
                    <label className="chk" title="Disable to see the non-ML fallback order"><input type="checkbox" checked={useMl} onChange={(e) => setUseMl(e.target.checked)} />use ML</label>
                    <button className="btn" disabled={busy} onClick={runAnalysis}><Search size={14} />Run Analysis</button>
                    {busy && expId && conn !== "" && conn !== "finished" ? <button className="btn danger" onClick={cancel}><StopCircle size={14} />Cancel</button> : <button className="btn primary" disabled={busy} onClick={optimize}><Play size={14} />Optimize Code</button>}
                    <button className="btn" onClick={reset}><RotateCcw size={14} />Reset</button>
                  </div>
                </div>
                <div className="col">
                  <Pipeline stages={stages} state={pstate} connection={conn} />
                  <AnalysisSummary a={analysis} compact />
                </div>
              </div>
              {exp ? <Results exp={exp} reload={() => loadResults(exp.id)} /> : <div className="empty big">Run “Optimize Code” to compile, optimise, verify and benchmark your program. Results, charts and variant source will appear here.</div>}
            </>
          )}
          {page === "analysis" && <AnalysisPage a={analysis} run={runAnalysis} busy={busy} />}
          {page === "benchmarks" && <BenchPage exp={exp} reload={() => exp && loadResults(exp.id)} />}
          {page === "history" && <HistoryPage open={openExperiment} />}
          {page === "ml" && <MLPage ml={ml} refresh={refreshStatus} />}
          {page === "settings" && <SettingsPage />}
        </main>
      </div>
    </div>
  );
}

function Stat({ k, v, tone }) { return <div className={`stat ${tone || ""}`}><div className="k">{k}</div><div className="v">{v ?? "—"}</div></div>; }

function AnalysisSummary({ a, compact }) {
  if (!a) return <div className="panel"><div className="panel-h"><span>Analysis summary</span></div><div className="empty">Press “Run Analysis” (or Optimize) to see compiler-derived features.</div></div>;
  const f = a.features || {}; const ir = a.ir_stats || {};
  return (
    <div className="panel"><div className="panel-h"><span>Analysis summary</span><span className={`pill ${a.compilation_status === "ok" ? "ok" : "bad"}`}>{a.compilation_status}</span></div>
      <div className="pad">
        {a.compilation_status === "error" && a.diagnostics.map((d, i) => <div key={i} className={`remark ${d.severity === "error" ? "missed" : ""}`}>{d.file}:{d.line}:{d.col} {d.severity}: {d.message}</div>)}
        {a.compilation_status === "ok" && <>
          <div className="grid4">
            <Stat k="Language" v={a.language?.toUpperCase()} /><Stat k="Lines" v={a.source_lines} /><Stat k="Functions (est.)" v={f.src_functions} />
            <Stat k="Loops (IR)" v={a.loops?.ir_count ?? `${a.loops?.source_count_heuristic} est.`} /><Stat k="Max loop depth" v={a.loops?.ir_max_depth ?? a.loops?.source_max_depth_heuristic} />
            <Stat k="Cond. branches (IR)" v={f.ir_cond_br} /><Stat k="IR instructions" v={f.ir_instr} /><Stat k="Loads/Stores" v={`${f.ir_loads ?? "—"}/${f.ir_stores ?? "—"}`} />
          </div>
          <div className="dim small">Compiler: {a.compiler_version}. “IR” values come from LLVM; “est.” values are lexer heuristics.</div>
          {a.opportunities?.length > 0 && <><h4>Detected opportunities</h4>{a.opportunities.map((o, i) => <div key={i} className="opp"><b>{o.title}</b> <span className="pill">{o.kind}</span><div className="dim small">{o.evidence}</div></div>)}</>}
          {a.warnings?.map((w, i) => <div key={i} className="note">{w}</div>)}
          {a.diagnostics?.filter((d) => d.severity === "warning").slice(0, compact ? 3 : 20).map((d, i) => <div key={i} className="note">line {d.line}: {d.message}</div>)}
        </>}
      </div></div>
  );
}

function AnalysisPage({ a, run, busy }) {
  if (!a) return <div className="empty big">No analysis yet. <button className="btn" onClick={run} disabled={busy}>Analyse the editor contents</button></div>;
  const ir = a.ir_stats || {};
  return (<div className="stack">
    <AnalysisSummary a={a} />
    {a.compilation_status === "ok" && <>
      <div className="panel"><div className="panel-h"><span>Feature vector (schema v{a.feature_schema_version})</span></div><div className="pad"><div className="dim small">{Object.entries(a.metric_provenance || {}).map(([k, v]) => `${k}: ${v}`).join(" · ")}</div>
        <div className="grid4">{Object.entries(a.features).map(([k, v]) => <Stat key={k} k={k} v={typeof v === "number" ? (Number.isInteger(v) ? v : v.toFixed(3)) : v} />)}</div></div></div>
      <div className="panel"><div className="panel-h"><span>LLVM IR statistics (O0 IR, mem2reg)</span></div><div className="pad"><div className="grid4">{Object.entries(ir).map(([k, v]) => <Stat key={k} k={k} v={v} />)}</div>
        <div className="dim small">IR instructions at −O0: {a.o0_ir_instructions ?? "—"} → at −O2: {a.o2_ir_instructions ?? "—"}</div></div></div>
      <div className="panel"><div className="panel-h"><span>Vectorisation diagnostics (clang -O3 remarks)</span></div><div className="pad">
        {a.vectorization_remarks?.length ? a.vectorization_remarks.map((r, i) => <div key={i} className={`remark ${r.status}`}>line {r.line}: {r.message}</div>) : <div className="dim">No loop-vectoriser remarks were produced.</div>}</div></div>
      <Complexity exp={{ complexity: a.complexity, variants: [], best_variant_id: null }} />
    </>}
  </div>);
}

function BenchPage({ exp, reload }) {
  if (!exp || !exp.variants?.length) return <div className="empty big">Run an optimisation (or open one from history) to see benchmark data.</div>;
  return (<div className="stack"><Banner r={exp} />
    <div className="panel"><div className="panel-h"><span>Benchmark results — {exp.id}</span></div><VariantTable variants={exp.variants} selected={null} onSelect={() => {}} /></div>
    <div className="panel"><div className="panel-h"><span>Charts</span></div><Charts variants={exp.variants} /></div>
    {exp.status === "completed" && <WhatIf exp={exp} onChange={reload} />}</div>);
}

function HistoryPage({ open }) {
  const [data, setData] = useState({ items: [], total: 0 }); const [q, setQ] = useState(""); const [sort, setSort] = useState("created_desc"); const [status, setStatus] = useState(""); const [lang, setLang] = useState(""); const [offset, setOffset] = useState(0);
  const load = () => { const p = { limit: 15, offset, sort }; if (q) p.q = q; if (status) p.status = status; if (lang) p.language = lang; api.list(p).then(setData).catch(() => {}); };
  useEffect(load, [q, sort, status, lang, offset]);
  const del = async (id) => { if (!window.confirm(`Delete ${id} and its files?`)) return; try { await api.remove(id); load(); } catch (e) { alert(e.message); } };
  return (<div className="panel"><div className="panel-h"><span>Experiment history ({data.total})</span>
    <div className="row"><input placeholder="Filter by label / id / strategy" value={q} onChange={(e) => { setQ(e.target.value); setOffset(0); }} />
      <select value={status} onChange={(e) => setStatus(e.target.value)}><option value="">any status</option><option>completed</option><option>failed</option><option>cancelled</option></select>
      <select value={lang} onChange={(e) => setLang(e.target.value)}><option value="">C & C++</option><option value="c">C</option><option value="cpp">C++</option></select>
      <select value={sort} onChange={(e) => setSort(e.target.value)}><option value="created_desc">Newest</option><option value="created_asc">Oldest</option><option value="speedup_desc">Best speedup</option><option value="baseline_desc">Slowest baseline</option></select></div></div>
    <div className="tablewrap"><table className="tbl"><thead><tr><th>ID</th><th>Date</th><th>Label</th><th>Lang</th><th>Compiler</th><th>ML pick</th><th>Best</th><th className="r">Baseline</th><th className="r">Best time</th><th>Status</th><th></th></tr></thead>
      <tbody>{data.items.map((e) => <tr key={e.id} onClick={() => open(e.id)}><td className="mono">{e.id}</td><td>{fmtTime(e.created_at)}</td><td>{e.label}</td><td>{e.language}</td><td className="dim">{e.compiler_version?.replace(/\(.*\)/, "")}</td>
        <td>{e.selected_strategy || "—"}{e.ml_source && e.ml_source !== "trained-model" && <span className="pill warn">fallback</span>}</td><td>{e.best_strategy || "—"} {e.best_speedup ? <span className="dim">({fmtX(e.best_speedup)})</span> : ""}</td>
        <td className="r">{fmtMs(e.baseline_median_ms)}</td><td className="r">{fmtMs(e.best_median_ms)}</td><td><span className={`pill ${e.status === "completed" ? "ok" : "bad"}`}>{e.status}</span></td>
        <td onClick={(ev) => ev.stopPropagation()}><button className="btn sm" onClick={() => del(e.id)}><Trash2 size={12} /></button></td></tr>)}
        {!data.items.length && <tr><td colSpan={11} className="empty">No experiments yet.</td></tr>}</tbody></table></div>
    <div className="panel-f"><button className="btn sm" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - 15))}>Prev</button><span className="dim small">{offset + 1}–{Math.min(offset + 15, data.total)} of {data.total}</span><button className="btn sm" disabled={offset + 15 >= data.total} onClick={() => setOffset(offset + 15)}>Next</button></div></div>);
}

function MLPage({ ml, refresh }) {
  const [m, setM] = useState(null); const [mode, setMode] = useState("quick"); const [err, setErr] = useState("");
  const load = () => api.mlMetrics().then(setM).catch(() => setM(null));
  useEffect(() => { load(); }, [ml?.version]);
  const job = ml?.training_job;
  useEffect(() => { if (job?.state !== "running") return; const t = setInterval(() => { refresh(); }, 2000); return () => clearInterval(t); }, [job?.state]);
  const train = async () => { setErr(""); try { await api.train({ mode }); refresh(); } catch (e) { setErr(e.message); } };
  const cv = m?.metrics?.cross_validation;
  const imp = m ? Object.entries(m.feature_importances).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([name, v]) => ({ name, v })) : [];
  return (<div className="stack">
    <div className="panel"><div className="panel-h"><span>Model status</span><span className={`pill ${ml?.available ? "ml" : "warn"}`}>{ml?.label || "unknown"}</span></div><div className="pad">
      {!ml?.available && <div className="note">No usable trained model — the optimizer runs in baseline mode (fixed candidate order, clearly labelled as not ML). Train one below or run <code>python -m backend.ml.train --data-dir data/benchmarks --output-dir artifacts</code>.</div>}
      {m && <div className="grid4"><Stat k="Version" v={m.version} /><Stat k="Trained" v={fmtTime(m.trained_at)} /><Stat k="Programs" v={m.n_programs} /><Stat k="Samples (prog×strategy)" v={m.dataset_size} /><Stat k="Model" v="Random Forest (regression/ranking)" /><Stat k="Feature schema" v={`v${m.feature_schema_version}`} /><Stat k="Features" v={m.feature_names.length} /><Stat k="Training mode" v={m.training_mode} /></div>}
      <div className="row" style={{ marginTop: 12 }}><select value={mode} onChange={(e) => setMode(e.target.value)}><option value="quick">Quick (36 programs, ~4 min)</option><option value="full">Full (72 programs, ~15+ min)</option></select>
        <button className="btn primary" disabled={job?.state === "running"} onClick={train}>{ml?.available ? "Retrain" : "Train"} model</button></div>
      {err && <div className="note bad">{err}</div>}
      {job?.state === "running" && <div className="note">Training: {job.stage} {job.done}/{job.total} — {job.message}. Benchmarks are timing-sensitive, so avoid running other heavy work.</div>}
      {job?.state === "failed" && <div className="note bad">{job.error}</div>}
    </div></div>
    {cv?.available && <div className="panel"><div className="panel-h"><span>Held-out evaluation</span><span className="dim small">{cv.method}; {cv.n_programs} programs, {cv.n_families} families</span></div><div className="pad">
      <div className={`note ${cv.verdict.includes("NOT") || cv.verdict.includes("indistinguishable") ? "" : "ok"}`}><b>{cv.verdict}.</b> Evidence for any claim comes only from these out-of-family measurements. “Near-optimal” = within 3% of the best measured candidate.</div>
      <table className="tbl"><thead><tr><th>Policy</th><th className="r">Near-optimal</th><th className="r">Top-1</th><th className="r">Mean regret</th><th className="r">Median speedup vs O0</th><th className="r">Beats O2</th><th className="r">Worse than O2</th></tr></thead>
        <tbody>{Object.values(cv.strategies).map((s) => <tr key={s.name}><td>{s.name}</td><td className="r">{(s.near_optimal_rate * 100).toFixed(0)}%</td><td className="r">{(s.top1_accuracy * 100).toFixed(0)}%</td><td className="r">{s.mean_regret_pct.toFixed(1)}%</td><td className="r">{s.median_speedup_vs_O0.toFixed(2)}×</td><td className="r">{s.beats_O2_pct.toFixed(0)}%</td><td className="r">{s.worse_than_O2_pct.toFixed(0)}%</td></tr>)}</tbody></table>
      <div className="dim small">Inference time {cv.inference_ms.toFixed(1)} ms per program. The oracle is the best measured candidate (an upper bound, not a prediction). Top-3 near-optimal rate: {(cv.strategies.ml.top3_near_optimal_rate * 100).toFixed(0)}%.</div></div></div>}
    {m && <div className="charts">
      <ChartBox title="Feature importance (impurity, global)" note="reliance of the model, not causation"><ResponsiveContainer><BarChart data={imp} layout="vertical" margin={{ left: 80 }}><CartesianGrid stroke={COLORS.grid} horizontal={false} /><XAxis type="number" stroke={COLORS.axis} fontSize={11} /><YAxis type="category" dataKey="name" stroke={COLORS.axis} fontSize={11} width={110} /><Tooltip {...TOOLTIP} /><Bar dataKey="v" fill={COLORS.ml} /></BarChart></ResponsiveContainer></ChartBox>
      {cv?.oracle_label_distribution && <ChartBox title="Training data: best strategy per program" note="count of programs for which each strategy was fastest (ties go to the first)"><ResponsiveContainer><BarChart data={Object.entries(cv.oracle_label_distribution).map(([name, n]) => ({ name, n }))} margin={{ bottom: 20 }}><CartesianGrid stroke={COLORS.grid} vertical={false} /><XAxis dataKey="name" stroke={COLORS.axis} fontSize={11} angle={-30} textAnchor="end" interval={0} height={50} /><YAxis stroke={COLORS.axis} fontSize={11} allowDecimals={false} /><Tooltip {...TOOLTIP} /><Bar dataKey="n" fill={COLORS.opt} /></BarChart></ResponsiveContainer></ChartBox>}
    </div>}
  </div>);
}

function SettingsPage() {
  const [c, setC] = useState(null);
  useEffect(() => { api.compiler().then(setC).catch(() => {}); }, []);
  if (!c) return <div className="empty big">Loading compiler status…</div>;
  return (<div className="stack">
    <div className="panel"><div className="panel-h"><span>Toolchain (auto-detected)</span><button className="btn sm" onClick={() => api.compiler().then(setC)}>Refresh</button></div><div className="pad">
      {c.problems?.map((p, i) => <div key={i} className="note bad">{p}</div>)}
      <table className="tbl small"><thead><tr><th>Tool</th><th>Status</th><th>Path</th><th>Version</th></tr></thead><tbody>{Object.entries(c.tools).map(([k, t]) => <tr key={k}><td>{k}</td><td><span className={`pill ${t.available ? "ok" : "bad"}`}>{t.available ? "found" : "missing"}</span></td><td className="mono dim">{t.path || "—"}</td><td className="dim">{t.version?.split("\n")[0]}</td></tr>)}</tbody></table>
      <div className="dim small">Override with CLANG_PATH / LLVM_BIN_DIR in .env (see .env.example).</div></div></div>
    <div className="panel"><div className="panel-h"><span>Optimisation strategies</span></div><div className="pad"><table className="tbl small"><thead><tr><th>ID</th><th>Kind</th><th>Flags / pipeline</th><th>Available</th></tr></thead><tbody>{c.strategies.map((s) => <tr key={s.id}><td><b>{s.id}</b></td><td>{s.kind}</td><td className="mono dim">{s.flags.join(" ") || s.pipeline?.slice(0, 70)}</td><td>{s.available ? <span className="pill ok">yes</span> : <span className="pill bad" title={s.unavailable_reason}>{s.unavailable_reason}</span>}</td></tr>)}</tbody></table></div></div>
    <div className="panel"><div className="panel-h"><span>Limits & safety</span></div><div className="pad"><div className="grid4">{Object.entries(c.limits).map(([k, v]) => <Stat key={k} k={k} v={v} />)}</div><div className="note">{c.isolation_warning}</div></div></div>
  </div>);
}

function Overview({ health, ml, go, open }) {
  const [recent, setRecent] = useState([]);
  useEffect(() => { api.list({ limit: 5 }).then((d) => setRecent(d.items)).catch(() => {}); }, []);
  return (<div className="stack">
    <div className="grid4">
      <Stat k="Backend" v={health ? health.status : "offline"} tone={health ? "ok" : "bad"} /><Stat k="Compiler" v={health?.compiler?.available ? health.compiler.version?.replace(/\(.*\)/, "") : "missing"} tone={health?.compiler?.available ? "ok" : "bad"} />
      <Stat k="IR pass pipelines" v={health?.compiler?.ir_pipelines ? "available" : "unavailable"} /><Stat k="ML model" v={ml?.available ? ml.version : "not trained"} tone={ml?.available ? "ok" : "warn"} /></div>
    <div className="panel"><div className="panel-h"><span>How it works</span></div><div className="pad flow">
      {["Source in", "Clang → LLVM IR", "Feature extraction", "ML ranks strategies", "Build ≥4 distinct variants", "Verify output vs −O0", "Benchmark (median, IQR)", "Measured winner"].map((s, i) => <div key={i} className="step"><b>{i + 1}</b>{s}</div>)}
    </div><div className="pad dim small">The winner is chosen only from measured, correct, non-duplicate variants. Close results are reported as a practical tie.</div></div>
    <div className="panel"><div className="panel-h"><span>Recent experiments</span><button className="btn sm" onClick={() => go("history")}>All history</button></div>
      <div className="tablewrap"><table className="tbl"><tbody>{recent.map((e) => <tr key={e.id} onClick={() => open(e.id)}><td className="mono">{e.id}</td><td>{e.label}</td><td>{e.best_strategy || "—"}</td><td className="r">{fmtX(e.best_speedup)}</td><td><span className={`pill ${e.status === "completed" ? "ok" : "bad"}`}>{e.status}</span></td></tr>)}{!recent.length && <tr><td className="empty">No experiments yet — open the Code Optimizer.</td></tr>}</tbody></table></div></div>
    <button className="btn primary" style={{ width: 200 }} onClick={() => go("optimizer")}>Open Code Optimizer</button>
  </div>);
}
