import React from "react";
import { Bar, BarChart, CartesianGrid, Cell, ErrorBar, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis, ReferenceLine } from "recharts";

const C = { base: "#6b7686", opt: "#3fb68b", win: "#e5a935", ml: "#4aa3d8", bad: "#d9534f", grid: "#2b323c", axis: "#8b95a3" };
const tt = { contentStyle: { background: "#161a20", border: "1px solid #2b323c", fontSize: 12 }, labelStyle: { color: "#e6e9ee" } };

function Box({ title, note, children }) {
  return <div className="chart"><div className="chart-t">{title}</div>{note && <div className="chart-n">{note}</div>}<div className="chart-b">{children}</div></div>;
}
const color = (v) => (v.is_winner ? C.win : v.is_baseline ? C.base : v.ml_selected ? C.ml : C.opt);
const measured = (variants) => variants.filter((v) => v.median_ms != null);

export default function Charts({ variants }) {
  const m = measured(variants);
  if (!m.length) return <div className="empty">No measurements to chart.</div>;
  const time = m.map((v) => ({ name: v.strategy_id, v, median: v.median_ms, err: [v.median_ms - v.min_ms, v.max_ms - v.median_ms] }));
  const sp = m.map((v) => ({ name: v.strategy_id, v, speedup: v.speedup }));
  const size = variants.filter((v) => v.binary_size).map((v) => ({ name: v.strategy_id, v, kb: v.binary_size / 1024 }));
  const levels = ["O0", "O1", "O2", "O3"].map((id) => m.find((v) => v.strategy_id === id)).filter(Boolean);
  const mlv = m.find((v) => v.ml_selected);
  const lv = levels.map((v) => ({ name: v.strategy_id, v, median: v.median_ms }));
  if (mlv && !levels.includes(mlv)) lv.push({ name: `ML: ${mlv.strategy_id}`, v: mlv, median: mlv.median_ms });
  else if (mlv) lv.forEach((d) => { if (d.v === mlv) d.name = `${d.name} (ML pick)`; });
  const vari = m.map((v) => ({ name: v.strategy_id, v, cv: v.median_ms ? (v.iqr_ms / v.median_ms) * 100 : 0 }));
  const axis = { stroke: C.axis, fontSize: 11 };
  const common = { margin: { top: 8, right: 12, left: 0, bottom: 28 } };
  const X = <XAxis dataKey="name" {...axis} angle={-30} textAnchor="end" interval={0} height={50} />;
  const cells = (d) => d.map((x, i) => <Cell key={i} fill={color(x.v)} />);
  return (
    <div className="charts">
      <Box title="Execution time (median, whiskers = min–max)" note="milliseconds; lower is better">
        <ResponsiveContainer><BarChart data={time} {...common}><CartesianGrid stroke={C.grid} vertical={false} />{X}
          <YAxis {...axis} unit=" ms" /><Tooltip {...tt} formatter={(v) => `${(+v).toFixed(2)} ms`} />
          <Bar dataKey="median">{cells(time)}<ErrorBar dataKey="err" stroke="#e6e9ee" width={4} /></Bar></BarChart></ResponsiveContainer>
      </Box>
      <Box title="Speedup vs −O0 baseline" note="baseline median ÷ variant median; dashed line = 1×">
        <ResponsiveContainer><BarChart data={sp} {...common}><CartesianGrid stroke={C.grid} vertical={false} />{X}
          <YAxis {...axis} unit="×" /><Tooltip {...tt} formatter={(v) => `${(+v).toFixed(2)}×`} /><ReferenceLine y={1} stroke="#8b95a3" strokeDasharray="4 4" />
          <Bar dataKey="speedup">{cells(sp)}</Bar></BarChart></ResponsiveContainer>
      </Box>
      <Box title="Executable size" note="kilobytes of the linked binary (includes runtime stubs)">
        <ResponsiveContainer><BarChart data={size} {...common}><CartesianGrid stroke={C.grid} vertical={false} />{X}
          <YAxis {...axis} unit=" KB" domain={["auto", "auto"]} /><Tooltip {...tt} formatter={(v) => `${(+v).toFixed(2)} KB`} />
          <Bar dataKey="kb">{cells(size)}</Bar></BarChart></ResponsiveContainer>
      </Box>
      <Box title="Optimisation levels vs ML-selected strategy" note={mlv ? "ML pick from the trained model" : "No trained-model pick in this run"}>
        <ResponsiveContainer><BarChart data={lv} {...common}><CartesianGrid stroke={C.grid} vertical={false} />{X}
          <YAxis {...axis} unit=" ms" /><Tooltip {...tt} formatter={(v) => `${(+v).toFixed(2)} ms`} />
          <Bar dataKey="median">{cells(lv)}</Bar></BarChart></ResponsiveContainer>
      </Box>
      <Box title="Benchmark variability" note="IQR as % of median; higher = noisier measurement">
        <ResponsiveContainer><BarChart data={vari} {...common}><CartesianGrid stroke={C.grid} vertical={false} />{X}
          <YAxis {...axis} unit="%" /><Tooltip {...tt} formatter={(v) => `${(+v).toFixed(1)}%`} />
          <Bar dataKey="cv" fill={C.base} /></BarChart></ResponsiveContainer>
      </Box>
    </div>
  );
}
export { Box as ChartBox, C as COLORS, tt as TOOLTIP };
